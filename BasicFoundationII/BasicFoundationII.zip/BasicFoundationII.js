//Biggie Size - Given an array, write a function that changes all 
//positive numbers in the array to the string "big".  Example:
// makeItBig([-1,3,5,-5]) returns that same array, changed to [-1, "big", "big", -5].

function makeItBig(arr) {
    for (i = 0; i < arr.length; i++) {
        if (arr[i] > 0) {
            arr[i] = "big";
        }
    }
    console.log(arr)
    return arr;
}
arr = [-1, 3, 5, -5]
makeItBig(arr)


//Print Low, Return High - Create a function that takes in an array of numbers.  
//The function should print the lowest value in the array, 
//and return the highest value in the array.

function lowToHigh(arr) {
    var max = arr[0];
    var min = arr[0];
    for (var i = 0; i < arr.length; i++) {
        if (max < arr[i]) {
            max = arr[i]
        }
        if (arr[i] < min) {
            min = arr[i]
        }
    }
    console.log(min)
    return max;
}


lowToHigh([2, 10, -2, 6])


//Print One, Return Another - Build a function that takes in an array of numbers.  
//The function should print the second-to-last value in the array, 
//and return the first odd value in the array.


//
function SecondLast(arr) {
    var firstodd = []; //this was created to allow me to store all odd numbers
    var output = arr[arr.length - 2]; //this tells the function to find the second to last value in any array
    for (var i = 0; i < arr.length; i++) {  //
        if (arr[i] % 2 == 1) {
            firstodd.push(arr[i]);
        }
    }
    console.log(output)
    return firstodd[0];
}

SecondLast(test);

// Double Vision - Given an array(similar to saying 'takes in an array'),
// create a function that returns a new array 
// where each value in the original array has been doubled.
// Calling double([1, 2, 3]) should return [2, 4, 6] without changing the original array.


//
function DoubleUp() {
    for (var i = 0; i < arr.length; i++) {
        arr[i] = arr[i] + arr[i];
        console.log
    }
}
